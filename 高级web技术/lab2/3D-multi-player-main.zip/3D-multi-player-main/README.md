# 3D-multi-player
Udemy course: https://www.udemy.com/course/create-a-3d-multi-player-game-using-threejs-and-socketio Learn to use the WebGL library THREE js, NODE.Js and Socket IO to create a 3D multi-player game.
