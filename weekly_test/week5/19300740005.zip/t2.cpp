#include <iostream>
#include <cmath>
#include <vector>
using namespace std;

// 这里的模式匹配处理要全面
void process(string equation, vector<string> &coef2, vector<string> &coef1, vector<string> &coef0){
    for (int i = 0; i < equation.length(); i++){
        if (equation[i+2] == 'x' && equation[i+3] == '^' && equation[i+4] == '2'){
            string temp = "";
            temp += equation[i];
            temp += equation[i+1];
            coef2.push_back(temp);
        }
        else if (equation[i+2] == 'x'){
            string temp = "";
            temp += equation[i];
            temp += equation[i+1];
            coef1.push_back(temp);
        }
        // 匹配常数项比较复杂
        else if ((equation[i+2] == '=' && (equation[i] != '^'  && equation[i+1] != 'x')) \
        || (i == equation.length()-2 && (equation[i] != '^' && equation[i+1] != 'x'))){
            string temp = "";
            temp += equation[i];
            temp += equation[i+1];
            coef0.push_back(temp);
        }
        else if (equation[i] == '='){
            string temp = "=";
            coef0.push_back(temp);
            coef1.push_back(temp);
            coef2.push_back(temp);
        }
    }
}

int main(){
    vector<string> coef2;
    vector<string> coef1;
    vector<string> coef0;
    string equation;
    cin >> equation;
    int A = 0;
    int B = 0;
    int C = 0;
    double delta;
    double x1, x2;

    // 字符串处理
    process(equation, coef2, coef1, coef0);
    int record2 = coef2.size();
    int record1 = coef1.size();
    int record0 = coef0.size();

    // 处理二次项
    for (int i = 0; i < coef2.size(); i++){
        if (coef2[i] == "="){
            record2 = i;
            break;
        }
    }

    for (int i = 0; i < coef2.size(); i++){
        if (coef2[i] != "="){
            string temp;
            temp += coef2[i];
            if (i < record2){
                A += atoi(temp.c_str());
            }
            else if (i > record2){
                A -= atoi(temp.c_str());
            }
        }
        else{
            continue;
        }
    }

    // 处理一次项
    for (int i = 0; i < coef1.size(); i++){
        if (coef1[i] == "="){
            record1 = i;
            break;
        }
    }

    for (int i = 0; i < coef1.size(); i++){
        if (coef1[i] != "="){
            string temp;
            temp += coef1[i];
            if (i < record1){
                B += atoi(temp.c_str());
            }
            else if (i > record1){
                B -= atoi(temp.c_str());
            }
        }
        else{
            continue;
        }
    }

    // 处理常数项
    for (int i = 0; i < coef0.size(); i++){
        if (coef0[i] == "="){
            record0 = i;
            break;
        }
    }

    for (int i = 0; i < coef0.size(); i++){
        if (coef0[i] != "="){
            string temp;
            temp += coef0[i];
            if (i < record0){
                C += atoi(temp.c_str());
            }
            else if (i > record0){
                C -= atoi(temp.c_str());
            }
        }
        else{
            continue;
        }
    }

    double a, b ,c;
    a = (double)A;
    b = (double)B;
    c = (double)C;
    delta = pow(b,2) - 4*a*c;

    if (delta <= -1e-10){
        cout << "No solution" << endl;
    }

    else if (fabs(delta) < 1e-10){
        x1 = (-b)/(2*a);
        printf("%.2lf\n", x1);
    }

    else if (delta >= 1e-10){
        x1 = (-b + sqrt(delta))/(2*a);
        x2 = (-b - sqrt(delta))/(2*a);
        printf("%.2lf\n", x1);
        printf("%.2lf\n", x2);
    }
    return 0;
}